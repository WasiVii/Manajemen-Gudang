<?php

namespace App\Models\Transaksi;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class PurchaseOrder extends Authenticatable
{
    use Notifiable;

    protected $table = 'purchase_order';
    
    protected $fillable = [
        'purchase_order_id', 'purchase_order_document_no', 'purchase_order_date', 'purchase_order_subject'
    ];

    public function quotation()
    {
        return $this->belongsTo('App\Models\Transaksi\Quotation', 'quotation_id', 'quotation_id');
    }

    public function partner()
    {
        return $this->belongsTo('App\Models\Masterdata\Partner', 'partner_id', 'partner_id');
    }
}
