<?php

namespace App\Models\Transaksi;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Quotation extends Authenticatable
{
    use Notifiable;

    protected $table = 'quotation';
    
    protected $fillable = [
        'quotation_id', 'quotation_document_no', 'quotation_document_date', 'quotation_subject', 'quotation_equipment_name', 'quotation_customer', 'quotation_note'
    ];

    public function status()
    {
        return $this->belongsTo('App\Models\Transaksi\Status', 'status_id', 'status_id');
    }

    public function partner()
    {
        return $this->belongsTo('App\Models\Masterdata\Partner', 'partner_id', 'partner_id');
    }
}
