<?php

namespace App\Models\Transaksi;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class AccountPayable_detail extends Authenticatable
{
    use Notifiable;

    protected $table = 'account_payable_detail';
    
    protected $fillable = [
        'account_payable_detail_id', 
        'account_payable_id', 
        'account_payable_detail_item', 
        'account_payable_detail_qty', 
        'account_payable_detail_uom', 
        'account_payable_detail_unit_price',
        'account_payable_detail_amount'
    ];
}
