<?php

namespace App\Models\Transaksi;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class AccountPayable extends Authenticatable
{
    use Notifiable;

    protected $table = 'account_payable';
    
    protected $fillable = [
        'account_payable_id', 'account_payable_document_no', 'account_payable_document_date', 'account_payable_description', 'purchase_order_id'
    ];

    public function status()
    {
        return $this->belongsTo('App\Models\Transaksi\Status', 'status_id', 'status_id');
    }

    public function purchase_order()
    {
        return $this->belongsTo('App\Models\Transaksi\PurchaseOrder', 'purchase_order_id', 'purchase_order_id');
    }

    public function partner()
    {
        return $this->belongsTo('App\Models\Masterdata\Partner', 'partner_id', 'partner_id');
    }
}