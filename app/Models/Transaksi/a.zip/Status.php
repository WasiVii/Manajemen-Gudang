<?php

namespace App\Models\Transaksi;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Status extends Authenticatable
{
    use Notifiable;

    protected $table = 'status';
    
    protected $fillable = [
        'status_id', 'status_name'
    ];

    public $timestamps = false;
}
