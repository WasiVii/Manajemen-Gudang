<?php

namespace App\Models\Transaksi;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Quotation_attachment extends Authenticatable
{
    use Notifiable;

    protected $table = 'quotation_attachment';
    
    protected $fillable = [
        'quotation_attachment_id', 
        'quotation_id', 
        'quotation_attachment_attachment', 
        'quotation_detail_description'
    ];
}
