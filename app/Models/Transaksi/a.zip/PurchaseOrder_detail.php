<?php

namespace App\Models\Transaksi;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class PurchaseOrder_detail extends Authenticatable
{
    use Notifiable;

    protected $table = 'purchase_order_detail';
    
    protected $fillable = [
        'purchase_order_detail_id', 
        'purchase_order_id', 
        'purchase_order_detail_type', 
        'purchase_order_detail_description', 
        'purchase_order_detail_qty', 
        'purchase_order_detail_uom', 
        'purchase_order_detail_unit_price',
        'purchase_order_detail_discount',
        'purchase_order_detail_ammount'
    ];
}
