<?php

namespace App\Models\Transaksi;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Quotation_detail extends Authenticatable
{
    use Notifiable;

    protected $table = 'quotation_detail';
    
    protected $fillable = [
        'quotation_detail_id', 
        'quotation_id', 
        'quotation_detail_type', 
        'quotation_detail_description', 
        'quotation_detail_qty', 
        'quotation_detail_uom', 
        'quotation_detail_unit_price',
        'quotation_detail_discount',
        'quotation_detail_ammount'
    ];
}
